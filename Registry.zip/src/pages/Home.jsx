import React from "react";

const Home = () => {
  return (
    <div>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam deserunt
        eius dolores voluptate molestiae. Commodi aspernatur minus perspiciatis
        est ducimus unde saepe expedita odit magnam sed, eaque necessitatibus
        ipsa non.
      </p>
    </div>
  );
};

export default Home;
